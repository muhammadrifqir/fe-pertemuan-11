import * as React from "react";
import Footer from "./Components/footer/footer";
import Header from "./Components/header";
import Main from "./Components/main";
import { Route, Routes } from "react-router-dom";
import CreateMovie from "./Components/pages/movie/create";
import PopularMovie from "./Components/pages/movie/popular";
import NowPlayingMovie from "./Components/pages/movie/nowplaying";
import TopRatedMovie from "./Components/pages/movie/toprated";
import Layout from "./Components/layout/layout";
import Home from "./Components/pages/Home";
import { ThemeProvider } from "styled-components";
import theme from "./utils/constants/theme";

/**
 * membuat component app
 * component utama ysng menampung components lain
 */

function App() {
  return (
    <ThemeProvider theme={theme}>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movie/create" element={<CreateMovie />} />
          <Route path="/movie/popular" element={<PopularMovie />} />
          <Route path="/movie/now" element={<NowPlayingMovie />} />
          <Route path="/movie/top" element={<TopRatedMovie />} />
        </Routes>
      </Layout>
    </ThemeProvider>
  );
}

export default App;
