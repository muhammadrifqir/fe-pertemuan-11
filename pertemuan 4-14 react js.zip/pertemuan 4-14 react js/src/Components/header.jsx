/**
 * membuat component header
 * component header menampilkan navigasi
 */
function Header() {
    return (
      <nav>
        <ul>
        <li>home</li>
        <li>about</li>
        <li>contact</li>
        </ul>
      </nav>
    );
  }

export default Header;