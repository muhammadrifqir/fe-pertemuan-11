import * as React from "react";
import Container from "../container/container";
import Footer from "../footer/footer";
import Navbar from "../navbar/Navbar";

function Layout(props) {
  return (
    <>
      <Navbar />
      <main>
        <Container>{props.children}</Container>
      </main>
      <Footer />
    </>
  );
}

export default Layout;
