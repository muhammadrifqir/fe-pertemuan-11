/**
 * import css module
 */
import StyledMovie from "./movie.styled";

function Movie(props) {
  // destructing props
  const { movie } = props;

  const tmdImage = 'https://image.tmdb.org/t/p/w300/${movie.poster._path}';
  const year = movie.year || movie.release_date;
  
  return (
    <StyledMovie>
      <img src={movie.poster} alt="" />
      <h3>{movie.title}</h3>
      <p>{movie.year}</p>
    </StyledMovie>
  );
}

export default Movie;
