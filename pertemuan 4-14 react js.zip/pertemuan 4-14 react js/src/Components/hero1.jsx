// import navbar, hero, movies, footer component
import Footer from "./footer/footer";
import Navbar from "./navbar/Navbar";
import Hero from "./hero/Hero";
import Movies from "./Movies/Movies";

/**
 * membuat component home
 * component utama ysng menampung components lain
 */
function Home() {
  return (
    <div>
      <Navbar />
      <main>
      <Hero />
      <Movies />
      </main>
      <Footer />
    </div>
  );
}

export default Home;
