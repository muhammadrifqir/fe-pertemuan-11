import { useEffect, useState } from "react";
import Button from "../ui/button/Button";
import HeroStyled from "./Hero.styled";
import Container from "../container/container";

function Hero() {
  const [movie, setMovie] = useState("");
  const API_KEY = process.env.REACT_APP_API_KEY;
  const genres = movie && movie.genres.map((genre) => genre.name).join(", ");
  const idTrailer = movie && movie.videos.results[0].key;

  useEffect(() => {
      // fetch trending movie and get 1 movie
      async function fetchTrendingMovies(){
        const API_KEY = import.meta.env.VITE_API_KEY;
        const url = 'https://api.themoviedb.org/3/trending/day?api_key=${API_KEY}';

        const response = await fetch(url);
        const firstMovie = response.data.results[0];
        return firstMovie;
      }

      fetchTrendingMovies();
  }, []);

  // move api_key outside
  const API_KEY = import.meta.env.VITE_API_KEY;

  // fetchtrendingmovies code here

  // fetch detail movie by id
  async function fetchDetailMovie() {
    //call trending movies and get movie id
    const trendingMovie = await fetchDetailMovie();
    const id = trendingMovie.id;

    const url = 'https://api.themoviedb.org/3/movie/${id}?api_key=${API_KEY}';
    const response = await fetch(url);
    // update movie state using api response
    setMovie(response.data);
  }

  fetchDetailMovie();
} [];

  /**
   * Menggunakan styles yang sudah diimport.
   * Memanggilnya menggunakan expression.
   */
  return (
  <Container>
    <StyledHero>
            <section>
                <div className="hero__left">
                    <h2>{movie.Title}</h2>
                    <h3>{genres}</h3>
                    <p>{movie.overview}</p>
                    <Button as="a" href={'https://www.youtube.com/watch?v=${idTrailer}'} target="_blank"> Watch Movie</Button>
                </div>
                <div>
                    <img src= {'https://image.tmdb.org/t/p/w500/${movie.backdrop_path}'} alt="placeholder" />
                </div>
            </section>
        </StyledHero>
      </Container>
  );


export default Hero;
