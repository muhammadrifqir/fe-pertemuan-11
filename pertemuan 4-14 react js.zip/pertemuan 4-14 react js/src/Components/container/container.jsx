import * as React from "react";
// import styles from "./container.styled";

/**
 * membuat component container
 * menggunakan teknik composition: children
 */
function Container(props) {
  return <div className={""}>{props.children}</div>;
}

export default Container;
