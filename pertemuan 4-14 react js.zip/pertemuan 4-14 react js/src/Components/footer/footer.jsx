/**
 * Import CSS Module Footer.
 * Disimpan di object styles.
 */
import * as React from "react";
import FooterStyled from "./footer.styled";

function Footer() {
  /**
   * Menggunakan styles yang sudah diimport.
   * Memanggilnya menggunakan expression.
   */
  return (
    <FooterStyled>
      <footer>
        <h2>Movie App</h2>
        <p>
          Created by MUHAMMAD RIFQI ROBBANI
          <a href="https://github.com/muhammadrifqir/fe-semester-8">
            {" "}
            <br /> @muhammadrifqir
          </a>
        </p>
      </footer>
    </FooterStyled>
  );
}

export default Footer;
