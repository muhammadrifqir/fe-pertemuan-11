function CreateMovie(){
  return (
      <div>
          <h2>Create Movie</h2>
      </div>
  )
}

export default CreateMovie