function ToptRatedMovie(){
  return (
      <div>
          <h2>Top Rated Movie</h2>
      </div>
  );
}

export default ToptRatedMovie;