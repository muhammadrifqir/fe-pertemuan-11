import { useEffect, useState } from "react";
import axios from "axios";
//import Hero from "../hero/Hero";
//import Movies from "../Movies/Movies";
function PopularMovie(){
  const [movies, setMovies] = useState([]);

  useEffect(() => { 
    // memanggil function getpopularmovie
    getPopularMovies();
  });

    //async function fetchPopularMovies() {
      //const API_KEY = import.meta.env.VITE_API-KEY;
      //const URL = 'https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}';

    // membuat fungsi getpopularmovies: mengambil movies populer 
    async function getPopularMovies() {
      const response = await axios(URL);
      setMovies(response.data.results);
    }
  }

    fetchPopularMovies();
  [];

  // useeffect code here.

  // render movies component
  // passing movies props with movies state
  return(
    <div>
      <Hero />
      <Movies movies={movies} />
    </div>
  );


export default PopularMovie;