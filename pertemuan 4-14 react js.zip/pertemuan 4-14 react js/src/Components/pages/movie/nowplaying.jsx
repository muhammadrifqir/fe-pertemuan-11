function NowPlaying(){
  return (
      <div>
          <h2>Now Playing</h2>
      </div>
  );
}

export default NowPlaying;