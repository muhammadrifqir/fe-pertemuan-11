async function fetchMovie() {
    const url = 
    https://www.omdapi.com/?apikey=fcf50ae6&i=tt2975590;
    const response = await fetch(url);
    const data = await response.json();
}